DEPLOYMENT INSTRUCTIONS (SEPARATE ZIPS)

1. FRONTEND:
   - Unzip 'frontend-dist.zip' into a 'dist' folder in your app root.

2. BACKEND:
   - Unzip 'backend-deploy.zip' into your app root.
   - This includes your secrets (.env, service-account.json).
   - DOES NOT include package-lock.json (to avoid OS conflicts).

3. IF ERRORS PERSIST (ENOTEMPTY):
   - STOP the app in cPanel.
   - Run 'sh deploy-fix.sh' in Terminal.
   - OR Manually delete the 'nodevenv' folder in your home directory.

