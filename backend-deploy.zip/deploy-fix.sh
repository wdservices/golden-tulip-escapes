#!/bin/bash
echo '1. FORCE KILLING all node processes...'
pkill -u $(whoami) node || true
pkill -9 -u $(whoami) node || true
sleep 3
echo '2. Cleaning up npm cache...'
npm cache clean --force
echo '3. Removing local artifacts...'
rm -rf node_modules
rm -f package-lock.json
echo '4. Attempting to remove corrupted virtual environment...'
rm -rf ~/nodevenv/backend
rm -rf ~/nodevenv/goldentulip
echo '5. Installing dependencies from scratch...'
npm install --no-package-lock --no-audit
echo 'Done! Try starting your app now.'

